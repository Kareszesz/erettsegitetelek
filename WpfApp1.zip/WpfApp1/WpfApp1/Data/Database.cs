using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace WpfApp1.Data
{
    // A much simpler implementation: store everything in a JSON file.
    // This is easier to read and understand for a high-school project.
    public static class Database
    {
        private static string DbPath => System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tetelek.json");
        private static readonly object _lock = new object();

        class DataModel
        {
            public List<Subject> Subjects { get; set; } = new List<Subject>();
        }

        private static DataModel LoadAll()
        {
            lock (_lock)
            {
                if (!File.Exists(DbPath)) return new DataModel();
                var txt = File.ReadAllText(DbPath);
                if (string.IsNullOrWhiteSpace(txt)) return new DataModel();
                try
                {
                    var model = JsonSerializer.Deserialize<DataModel>(txt);
                    return model ?? new DataModel();
                }
                catch
                {
                    try
                    {
                        var list = JsonSerializer.Deserialize<List<Subject>>(txt);
                        return new DataModel { Subjects = list ?? new List<Subject>() };
                    }
                    catch
                    {
                        return new DataModel();
                    }
                }
            }
        }

        private static void SaveAll(DataModel model)
        {
            lock (_lock)
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                var txt = JsonSerializer.Serialize(model, options);
                File.WriteAllText(DbPath, txt);
            }
        }

        public static void Initialize()
        {
            lock (_lock)
            {
                if (!File.Exists(DbPath))
                {
                    SaveAll(new DataModel());
                }
            }
        }

        public static int AddSubject(string name, int? writtenScore)
        {
            var model = LoadAll();
            var existing = model.Subjects.FirstOrDefault(s => string.Equals(s.Name, name, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                if (writtenScore.HasValue) existing.WrittenScore = writtenScore;
                SaveAll(model);
                return existing.Id;
            }
            var id = model.Subjects.Any() ? model.Subjects.Max(s => s.Id) + 1 : 1;
            var subj = new Subject { Id = id, Name = name, WrittenScore = writtenScore };
            model.Subjects.Add(subj);
            SaveAll(model);
            return id;
        }

        public static IEnumerable<Subject> GetSubjects()
        {
            var model = LoadAll();
            return model.Subjects.Select(s => new Subject { Id = s.Id, Name = s.Name, WrittenScore = s.WrittenScore, Items = new List<Item>(s.Items) }).ToList();
        }

        public static int AddItem(Item item)
        {
            var model = LoadAll();
            var subj = model.Subjects.FirstOrDefault(s => s.Id == item.SubjectId);
            if (subj == null) return 0;
            var id = model.Subjects.SelectMany(s => s.Items).Any() ? model.Subjects.SelectMany(s => s.Items).Max(i => i.Id) + 1 : 1;
            item.Id = id;
            subj.Items.Add(item);
            SaveAll(model);
            return id;
        }

        public static IEnumerable<Item> GetItems(int subjectId)
        {
            var model = LoadAll();
            var subj = model.Subjects.FirstOrDefault(s => s.Id == subjectId);
            if (subj == null) return new List<Item>();
            return subj.Items.Select(i => new Item
            {
                Id = i.Id,
                SubjectId = i.SubjectId,
                Number = i.Number,
                Title = i.Title,
                Description = i.Description,
                Learned = i.Learned,
                LearnedDate = i.LearnedDate,
                Difficulty = i.Difficulty
            }).ToList();
        }

        public static void UpdateItemLearned(int itemId, bool learned)
        {
            var model = LoadAll();
            var found = model.Subjects.SelectMany(s => s.Items).FirstOrDefault(i => i.Id == itemId);
            if (found == null) return;
            found.Learned = learned;
            found.LearnedDate = learned ? DateTime.Now : (DateTime?)null;
            SaveAll(model);
        }

        public static void ExportJson(string filePath)
        {
            var model = LoadAll();
            var options = new JsonSerializerOptions { WriteIndented = true };
            var txt = JsonSerializer.Serialize(model, options);
            File.WriteAllText(filePath, txt);
        }

        public static void ImportJson(string filePath)
        {
            if (!File.Exists(filePath)) return;
            var txt = File.ReadAllText(filePath);
            if (string.IsNullOrWhiteSpace(txt)) return;
            DataModel incoming;
            try
            {
                incoming = JsonSerializer.Deserialize<DataModel>(txt) ?? new DataModel();
            }
            catch
            {
                try
                {
                    var list = JsonSerializer.Deserialize<List<Subject>>(txt) ?? new List<Subject>();
                    incoming = new DataModel { Subjects = list };
                }
                catch
                {
                    return;
                }
            }

            var model = LoadAll();
            foreach (var s in incoming.Subjects)
            {
                var existing = model.Subjects.FirstOrDefault(x => string.Equals(x.Name, s.Name, StringComparison.OrdinalIgnoreCase));
                if (existing == null)
                {
                    var newId = model.Subjects.Any() ? model.Subjects.Max(x => x.Id) + 1 : 1;
                    s.Id = newId;
                    var nextItemId = model.Subjects.SelectMany(x => x.Items).Any() ? model.Subjects.SelectMany(x => x.Items).Max(i => i.Id) + 1 : 1;
                    foreach (var it in s.Items)
                    {
                        it.Id = nextItemId++;
                        it.SubjectId = s.Id;
                    }
                    model.Subjects.Add(s);
                }
                else
                {
                    var nextItemId = model.Subjects.SelectMany(x => x.Items).Any() ? model.Subjects.SelectMany(x => x.Items).Max(i => i.Id) + 1 : 1;
                    foreach (var it in s.Items)
                    {
                        if (!existing.Items.Any(ei => string.Equals(ei.Title, it.Title, StringComparison.OrdinalIgnoreCase)))
                        {
                            it.Id = nextItemId++;
                            it.SubjectId = existing.Id;
                            existing.Items.Add(it);
                        }
                    }
                }
            }

            SaveAll(model);
        }
    }
}
