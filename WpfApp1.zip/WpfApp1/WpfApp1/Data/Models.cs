using System;

namespace WpfApp1.Data
{
    public class Subject
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int? WrittenScore { get; set; }
        // Simple list of items belonging to this subject to make JSON storage easy
        public System.Collections.Generic.List<Item> Items { get; set; } = new System.Collections.Generic.List<Item>();
    }

    public class Item
    {
        public int Id { get; set; }
        public int SubjectId { get; set; }
        public int Number { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public bool Learned { get; set; }
        public DateTime? LearnedDate { get; set; }
        public int Difficulty { get; set; }
    }
}
