﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;
using WpfApp1.Data;
using Microsoft.Win32;
using System.IO;
using System.Text.Json;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Database.Initialize();
            LoadSubjects();
            SubjectsList.SelectionChanged += SubjectsList_SelectionChanged;
        }

        private void LoadSubjects()
        {
            SubjectsList.ItemsSource = Database.GetSubjects().ToList();
        }

        private void SubjectsList_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            if (SubjectsList.SelectedItem is Subject s)
            {
                WrittenScoreBox.Text = s.WrittenScore?.ToString() ?? string.Empty;
                LoadItems(s.Id);
                UpdateStats(s.Id);
            }
            else
            {
                ItemsList.ItemsSource = null;
                StatsText.Text = string.Empty;
            }
        }

        private void AddSubject_Click(object sender, RoutedEventArgs e)
        {
            var name = SubjectNameBox.Text?.Trim();
            if (string.IsNullOrEmpty(name)) return;
            Database.AddSubject(name, null);
            SubjectNameBox.Text = string.Empty;
            LoadSubjects();
        }

        private void SaveWrittenScore_Click(object sender, RoutedEventArgs e)
        {
            if (SubjectsList.SelectedItem is not Subject s) return;
            if (int.TryParse(WrittenScoreBox.Text, out var score))
            {
                // update in DB directly
                var dbPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tetelek.db");
                var connStr = new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder { DataSource = dbPath }.ToString();
                using var conn = new Microsoft.Data.Sqlite.SqliteConnection(connStr);
                conn.Open();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "UPDATE Subjects SET WrittenScore=@score WHERE Id=@id";
                cmd.Parameters.AddWithValue("@score", score);
                cmd.Parameters.AddWithValue("@id", s.Id);
                cmd.ExecuteNonQuery();
                LoadSubjects();
            }
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            if (SubjectsList.SelectedItem is not Subject s) return;
            var item = new Item
            {
                SubjectId = s.Id,
                Number = int.TryParse(ItemNumberBox.Text, out var n) ? n : 0,
                Title = ItemTitleBox.Text ?? string.Empty,
                Description = ItemDescriptionBox.Text ?? string.Empty,
                Difficulty = int.TryParse(ItemDifficultyBox.Text, out var d) ? d : 0,
                Learned = false
            };
            Database.AddItem(item);
            ItemNumberBox.Text = ItemTitleBox.Text = ItemDescriptionBox.Text = ItemDifficultyBox.Text = string.Empty;
            LoadItems(s.Id);
            UpdateStats(s.Id);
        }

        private void LoadItems(int subjectId)
        {
            ItemsList.ItemsSource = Database.GetItems(subjectId).ToList();
        }

        private void Item_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox cb && cb.Tag is int id)
            {
                Database.UpdateItemLearned(id, true);
                RefreshCurrentSubjectStats();
            }
        }

        private void Item_Unchecked(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox cb && cb.Tag is int id)
            {
                Database.UpdateItemLearned(id, false);
                RefreshCurrentSubjectStats();
            }
        }

        private void RefreshCurrentSubjectStats()
        {
            if (SubjectsList.SelectedItem is Subject s)
            {
                LoadItems(s.Id);
                UpdateStats(s.Id);
            }
        }

        private void UpdateStats(int subjectId)
        {
            var items = Database.GetItems(subjectId).ToList();
            var total = items.Count;
            var learned = items.Count(i => i.Learned);
            StatsText.Text = $"Összes tétel: {total}\nMegtanult: {learned}\nHátralévő: {total - learned}";
        }

        private void ExportJson_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog { Filter = "JSON fájl (*.json)|*.json", FileName = "tetelek.json" };
            if (dlg.ShowDialog() == true)
            {
                Database.ExportJson(dlg.FileName);
            }
        }

        private void ImportJson_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "JSON fájl (*.json)|*.json" };
            if (dlg.ShowDialog() == true)
            {
                Database.ImportJson(dlg.FileName);
                LoadSubjects();
            }
        }

        private void CalculateNeeded_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(CalcWrittenBox.Text, out var written))
            {
                CalcResult.Text = "Adj meg érvényes írásbeli pontszámot (0-100).";
                return;
            }
            // Simple calculation: thresholds for final grade (összpont): 90,75,60,40
            var thresholds = new[] { 90, 75, 60, 40 };
            var sb = new StringBuilder();
            foreach (var t in thresholds)
            {
                var need = t - written;
                if (need <= 0) sb.AppendLine($"Már elérhető: {t} (szint): nincs szükség további pontokra");
                else sb.AppendLine($"A(z) {t} ponthoz szükséges szóbeli pont: {need} (ha a maximális összpont 100)");
            }
            CalcResult.Text = sb.ToString();
        }

    }
}